#!/bin/bash

docker build -f Dockerfile -t time-to-corruption .
